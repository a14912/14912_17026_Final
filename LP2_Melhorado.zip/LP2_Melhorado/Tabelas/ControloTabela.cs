﻿/*
 Linguagens Programacao II
 Docente- Luis Ferreira
 2019-2020
 Gabriel Vieira - a14912
 Jorge Rocha - a17026
 */

using System;
using System.Collections.Generic;

namespace Tabelas
{
    [Serializable]
    class ControloTabela
    {
        #region ATIBUTES

        private List<TabelaC> tabelas;
        const int nTabelas = 10;


        #endregion

        #region CONSTRUTORES

        /// <summary>
        /// lista de catastrofes
        /// </summary>
        public ControloTabela()
        {
            this.tabelas = new List<TabelaC>();
        }

        #endregion

        #region PROPERTIES


        public List<TabelaC> Alltabelas
        {
            get { return tabelas; }
            set { tabelas = value; }
        }

        public static int NTabelas
        {
            get { return nTabelas; }
        }

        #endregion

        #region METODOS



        #endregion
    }
}
