﻿/*
 Linguagens Programacao II
 Docente- Luis Ferreira
 2019-2020
 Gabriel Vieira - a14912
 Jorge Rocha - a17026
 */

using System;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Linq;


namespace Tabelas
{
    class ControloGeral
    {
        #region Incendio Metodos

        /// <summary>
        /// Metodo para acrescentar 1 tsunami a uma catastrofe
        /// </summary>
        /// <param name="tsu">incendio</param>
        /// <returns>True or false</returns>
        public static bool AddTsunami(int tsu, TabelaC c)
        {
            if (c.TsunamiID.Count() < TabelaC.NCatastrofes)
            {
                if (c.TsunamiID.Contains(tsu) == false)
                {
                    c.TsunamiID.Add(tsu);
                }
                else return false;
            }
            else return false;

            return true;
        }

        /// <summary>
        /// Metodo para remover 1 tsunami de uma catastrofe
        /// </summary>
        /// <param name="i">incendio</param>
        /// <returns>true or false</returns>
        public static bool RemoveTsunami(int tsu, TabelaC c)
        {

            if (c.TsunamiID.Contains(tsu) == false)
            {
                c.TsunamiID.Remove(tsu);
            }
            else return false;


            return true;
        }

        /// <summary>
        /// Adicionar incendio a catastrofe
        /// </summary>
        /// <param name="i">incendio</param>
        /// <returns>true or false</returns>
        public static bool AddIncendio(int i, TabelaC c)
        {
            if (c.IncendioId.Count() < TabelaC.NCatastrofes)
            {
                if (c.IncendioId.Contains(i) == false)
                {
                    c.IncendioId.Add(i);
                }
                else return false;
            }
            else return false;

            return true;
        }

        /// <summary>
        /// Metodo que remove 1 incendio de catastrofe
        /// </summary>
        /// <param name="i">incendio</param>
        /// <returns>true or false</returns>
        public static bool RemoveIncendio(int i, TabelaC c)
        {

            if (c.IncendioId.Contains(i) == false)
            {
                c.IncendioId.Remove(i);
            }
            else return false;


            return true;
        }

        /// <summary>
        /// metodo que devolve um valor de uma posição da lista
        /// </summary>
        /// <param name="x">posição</param>
        /// <returns>valor da posição</returns>
        public static int TsunamiList(int tsu, TabelaC c)
        {
            return (c.TsunamiID[tsu]);
        }

        /// <summary>
        /// metodo que devolde a quantidade de tsunamis da lista
        /// </summary>
        /// <returns>Quantidade</returns>
        public static int TsunamiCount(TabelaC c)
        {
            return c.TsunamiID.Count();
        }

        /// <summary>
        /// metodo que devolve um valor de uma posição da lista
        /// </summary>
        /// <param name="x">posição</param>
        /// <returns>valor da posição</returns>
        public static int IncendioList(int i, TabelaC c)
        {
            return (c.IncendioId[i]);
        }

        /// <summary>
        /// metodo que devolde a quantidade de incendios da lista
        /// </summary>
        /// <returns>Quantidade</returns>
        public static int IncendioCount(TabelaC c)
        {
            return (c.IncendioId.Count());
        }

        public static bool ChangeStatus(Risco s, TabelaC c)
        {
            c.Risco = s;

            return true;
        }




        #endregion

        #region Cat METODOS

        /// <summary>
        /// remover uma catastrofe
        /// </summary>
        /// <param name="c">catastrofe</param>
        /// <returns>true or false</returns>
        public static bool RemoveTabelaC(TabelaC c, ControloTabela all)
        {
            if (all.Alltabelas.Contains(c) == false)
            {
                all.Alltabelas.Remove(c);
            }
            else return false;

            return true;

        }

        /// <summary>
        /// Inserir uma tabela de Catastrofes
        /// </summary>
        /// <param name="c">catastrofe</param>
        /// <returns>true or false</returns>
        public static bool AddTabelaC(TabelaC c, ControloTabela all)
        {

            if (all.Alltabelas.Count() < ControloTabela.NTabelas)
            {
                if (all.Alltabelas.Contains(c) == false)
                {
                    all.Alltabelas.Add(c);
                }
                else return false;
            }
            else return false;

            return true;
        }

        /// <summary>
        /// Mostra Array lista de tabelas
        /// </summary>
        public static void Show(ControloTabela all)
        {
            for (int i = 0; i < all.Alltabelas.Count; i++)
            {
                Console.WriteLine(all.Alltabelas[i].ToString());
            }
        }
        /// <summary>
        /// Mostra 1 Tabela
        /// </summary>
        /// <param name="c"></param>
        public static void Show(TabelaC c)
        {
            Console.WriteLine(c.ToString());
        }


        /// <summary>
        /// metodo para guardar os dados da lista de tabelas
        /// </summary>
        /// <param name="fileName">nome do ficheiro</param>
        /// <returns>true or false</returns>
        public static bool Save(string fileName, ControloTabela all)
        {
            // write the data to a file
            var binformatter = new BinaryFormatter();
            try
            {
                Stream s = File.Open(fileName, FileMode.Create, FileAccess.ReadWrite);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, all.Alltabelas);
                s.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }

        /// <summary>
        /// metodo para eliminar os dados guardados em memoria
        /// </summary>
        public static void Clear(ControloTabela all)
        {
            all.Alltabelas.Clear();
        }


        /// <summary>
        /// metodo para carregar os dados guardados no ficheiro bin
        /// </summary>
        /// <param name="fileName">nome do ficheiro</param>
        /// <returns>true or false</returns>
        public static bool Load(string fileName, ControloTabela all)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    all.Alltabelas = (List<TabelaC>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    Console.Write("ERRO:" + e.Message);
                    return false;
                }
            }
            return false;
        }


        /// <summary>
        /// guarda as tabelas em ficheiro txt
        /// </summary>
        /// <param name="fileName">caminho do ficheiro</param>
        /// <returns>true or false</returns>
        public static bool SaveTxt(string fileName, ControloTabela all)
        {
            
            if (File.Exists(fileName))
            {
                try
                {
                    //apaga o ficheiro ja existente para criar um novo
                    File.Delete(@"C:\Utilizadores\Utilizador\Desktop\LP2TB\alltabelas.txt");
                    StreamWriter sw = File.CreateText(fileName);

                    for (int i = 0; i < all.Alltabelas.Count; i++)
                    {
                        sw.WriteLine(all.Alltabelas[i].ToString());
                    }
                    sw.Flush();
                    sw.Close();

                    return true;
                }
                catch (Exception e)
                {
                    Console.Write("ERRO:" + e.Message);
                    return false;
                }
            }
            else
            {

                StreamWriter sw = File.CreateText(fileName);
                for (int i = 0; i < all.Alltabelas.Count; i++)
                {
                    sw.WriteLine(all.Alltabelas[i].ToString());
                }

                sw.Flush();
                sw.Close();
            }
            return false;
        }


        #endregion
    }
}

