﻿/*
 Linguagens Programacao II
 Docente- Luis Ferreira
 2019-2020
 Gabriel Vieira - a14912
 Jorge Rocha - a17026
 */
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Incendio;
using Tabelas;

namespace Apresentacao
{
    class Program
    {
        static void Main(string[] args)
        {

            IncendioControlo incendioControlo = new IncendioControlo();
            incendioControlo.Load(@"C:\Utilizadores\Utilizador\Desktop\LP2TB\incendios.bin");

            TsunamiControlo tsunamiControlo = new TsunamiControlo();
            tsunamiControlo.Load(@"C:\Utilizadores\Utilizador\Desktop\LP2TB\tsunamis.bin");


            int number = -1; //option number

            #region Dados tabelas incendios

            Incendio p1 = new Incendio(1, "i1", tipo.incendio, 6239, 1, "POrto", Status.ativo);
            Incendio p3 = new Incendio(3, "i2", tipo.incendio, 3245, 3, "Algarve", Status.extinto);
            Incendio p2 = new Incendio(2, "i3", tipo.incendio, 8396, 2, "Braga", Status.ativo);

            
            //IncendioControlo incendioControlo = new IncendioControlo();

            TabelaC c1 = new TabelaC(1, "incendio", "16-05-2020", Risco.medio);
            TabelaC c2 = new TabelaC(2, "incendio", "30-05-2020", Risco.baixo);
            TabelaC c3 = new TabelaC(3, "incendio", "01-06-2020", Risco.baixo);

            TabelaC c4 = new TabelaC(4, "tsunami", "10-02-2020", Risco.medio);
            TabelaC c5 = new TabelaC(5, "tsunami", "3-05-2020", Risco.baixo);
            TabelaC c6 = new TabelaC(6, "tsunami", "10-06-2020", Risco.alto);

            ControloGeral.AddIncendio(p1.Area, c1);
            ControloGeral.AddIncendio(p3.Area, c1);
            ControloGeral.AddIncendio(p2.Area, c2);



            ControloTabela all = new ControloTabela();
            ControloGeral.AddTabelaC(c1,all);
            ControloGeral.AddTabelaC(c2, all);
            ControloGeral.AddTabelaC(c3, all);
            TabelaCIncendiosList(c1, incendioControlo);
            ControloGeral.ChangeStatus(Risco.baixo, c1);
            TabelaCIncendiosList(c2, incendioControlo);
            
            ControloGeral.AddTabelaC(c4, all);
            ControloGeral.AddTabelaC(c5, all);
            ControloGeral.AddTabelaC(c6, all);
            TabelaCTsunamisList(c4, tsunamiControlo);
            ControloGeral.ChangeStatus(Risco.baixo, c4);
            TabelaCTsunamisList(c5, tsunamiControlo);
            #endregion


            #region Menu
            do
            {
                Console.Clear();
                Console.WriteLine("      Gestao de Catastrofes ");
                Console.WriteLine("0-Sair");
                Console.WriteLine("1-Adicionar Incendio");
                Console.WriteLine("2-Listar Incendios");
                Console.WriteLine("3-Eliminar Incendios");
                Console.WriteLine("4-Guardar Incendios");
                Console.WriteLine("5-Listar todas as Tabelas de Catastrofes");
                Console.WriteLine("6-Criar Tabela");
                Console.WriteLine("OP:");
                bool success;
                do
                {
                    success = Int32.TryParse(Console.ReadLine(), out number);
                    if (!success) { Console.WriteLine("opcao errada"); Console.WriteLine("OP:"); }
                } while (!success);
                if (success == true && number > -1 && number <= 6)
                {
                    switch (number)
                    {
                        case 0:
                            Console.Clear();
                            break;

                        case 1:
                            Console.Clear();
                            Console.WriteLine("Identificacao:");
                            bool success1 = Int32.TryParse(Console.ReadLine(), out int id);
                            Console.WriteLine("Nome:");
                            string s = Console.ReadLine();
                            bool success3 = false;
                            int g = -1;
                            tipo g1 = tipo.incendio;
                            while (!success3)
                            {
                                Console.WriteLine("Tipo Catastrofe (1-Incendio 2-Tsunami):");
                                success3 = Int32.TryParse(Console.ReadLine(), out g);
                                if (g < 1 || g > 2) { success3 = false; } else { if (g == 1) { g1 = tipo.incendio; } else { g1 = tipo.tsunami; } }
                            }
                            //Criacao de Incendio
                            Incendio incendio = new Incendio(id, s, g1);
                            try
                            {
                                incendioControlo.CreateIncendio(incendio);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;

                        case 2:
                            Console.Clear();
                            Console.WriteLine(" Gestao de Catastrofes ");
                            List<Incendio> aux = incendioControlo.ListAllIncendios();
                            
                            Console.WriteLine("ID\tName\t\t\t\tTipo\t     ");
                            
                            foreach (Incendio item in aux)
                                Console.WriteLine("{0}\t{1}\t\t\t\t{2}", item.Id, item.Name, item.Tipo);

                            Console.WriteLine("\nexit");
                            Console.ReadKey();
                            break;


                        case 3:
                            Console.WriteLine("Inserir identificacao incendio:");
                            bool success4 = Int32.TryParse(Console.ReadLine(), out g);
                            //try { incendioControlo.DeleteIncendioById(g); }catch(Exception e) { Console.WriteLine("Erro" + e.Message); }
                            int before = incendioControlo.NumberOfIncendios();
                            incendioControlo.DeleteIncendioById(g);
                            if (incendioControlo.NumberOfIncendios() < before) { Console.WriteLine("Incendio removido!"); }
                            Console.ReadKey();
                            break;
                        case 4:
                            try
                            {
                                incendioControlo.Save(@"C:\Utilizadores\Utilizador\Desktop\LP2TB\incendios.bin");
                            }
                            catch (Exception e) { Console.Write("Error:" + e.Message); }
                            Console.WriteLine("Saved.");
                            Console.ReadKey();
                            break;

                        case 5:
                            ControloGeral.Show(all);
                            Console.ReadKey();
                            break;
                        case 6:
                            Console.WriteLine("ID:");
                            success3 = Int32.TryParse(Console.ReadLine(), out id);
                            Console.WriteLine("Local:");
                            string m = Console.ReadLine();
                            Console.WriteLine("Data:");
                            string dt = Console.ReadLine();
                            Console.WriteLine("Status( 0-Ativo " + " 1-Extinto ");
                            success4 = Int32.TryParse(Console.ReadLine(), out int st);
                            while (!success4)
                            {
                                Console.WriteLine("Opção incorreta!");
                                Console.WriteLine("Status( 0-Ativo " + " 1-Extinto ");
                                success4 = Int32.TryParse(Console.ReadLine(), out st);
                            }

                            TabelaC f = new TabelaC(id, m, dt, (Risco)st);
                            ControloGeral.AddTabelaC(f, all);
                            Console.ReadKey();
                            break;


                        default:
                            Console.WriteLine(" Gestao de Catastrofes ");
                            break;
                    }
                }
                else { Console.Clear(); Console.WriteLine("Opcao Errada."); }
            } while (number != 0);
            Console.WriteLine("Goodbye");
            Console.ReadLine();

            #endregion

            #region ControloTabela


            ControloGeral.Show(all);

            ControloGeral.Show(c1);

            ControloGeral.Save("alltabelas", all);

            ControloGeral.SaveTxt(@"C:\Utilizadores\Utilizador\Desktop\LP2TB\alltabelas.txt", all);

            ControloGeral.Clear(all);

            ControloGeral.Load("alltabela", all);

            Console.ReadLine();
            #endregion 
            utente u1 = new ....
                BL.Add(utente)
            

        }
        
        #region Listas
       
        public static void TabelaCIncendiosList(TabelaC c, IncendioControlo all)
        {
            for (int i = 0; i < ControloGeral.IncendioCount(c); i++)
            {
                Console.WriteLine("Area: " + ControloGeral.IncendioList(i, c).ToString() + ", Nome: " + all.NameById(ControloGeral.IncendioList(i, c)));
            }
        }

        public static void TabelaCTsunamisList(TabelaC c, TsunamiControlo all)
        {
            for (int i = 0; i < ControloGeral.TsunamiCount(c); i++)
            {
                Console.WriteLine("Total Vitimas: " + ControloGeral.TsunamiList(i, c).ToString() + ", Nome: " + all.NameById(ControloGeral.TsunamiList(i, c)));
            }
        }
        #endregion
    }
}
