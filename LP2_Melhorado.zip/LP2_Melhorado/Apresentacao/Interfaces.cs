﻿/*
 Linguagens Programacao II
 Docente- Luis Ferreira
 2019-2020
 Gabriel Vieira - a14912
 Jorge Rocha - a17026
 */

using System.Collections.Generic;
using Incendio;
using Tabelas;

namespace Apresentacao
{
    interface Interfaces
    {
        interface IIncendioControl
        {
            bool AddIncendio(Incendio i);
            List<Incendio> ListAllIncendios();
            bool CreateIncendio(Incendio i);
            string NameByID(int id);
            bool ExistIncendio(Incendio i);
            bool DeleteIncendio(Incendio i);
            bool DeleteIncendioById(int i);
            bool Save(string path);
            bool Load(string path);


        }

        interface IDadosIncendio
        {



            bool CreateIncendio(Incendio i);
            List<Incendio> IncendioList();
            bool ExistIncendio(Incendio i);
            bool DeleteIncendio(Incendio i);
            bool DeleteIncendioById(int i);
            int Count();
            bool Save(string path);
            bool Load(string path);

        }

      
        }


    }
}
