﻿/*
 Linguagens Programacao II
 Docente- Luis Ferreira
 2019-2020
 Gabriel Vieira - a14912
 Jorge Rocha - a17026
 */



using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;


namespace Incendio
{
    [Serializable]
    class DadosIncendio
    {
        #region Lista para todos Incendios
        private List<Incendio> incList;
        #endregion

        #region Constructs
        public DadosIncendio()
        {
            this.incList = new List<Incendio>();
        }
        #endregion

        #region Methods

        public bool CreateIncendio(Incendio inc)
        {
            if (ExistIncendio(inc) == false)
            {
                int aux = incList.Count;
                try
                {
                    incList.Add(inc);
                }
                catch (Exception e) { throw new Exception(e.Message); }
                if (aux == incList.Count) { return true; } else { throw new Exception("Erro"); }
            }
            else { throw new Exception("Incendio existe"); }

        }
        public List<Incendio> IncendioList()
        {
            return incList;
        }
        bool ExistIncendio(Incendio inc)
        {
            if (incList.Contains(inc) == false) { return false; } else { return true; }
        }
        public bool DeleteIncendio(Incendio inc, Exception e)
        {
            if (ExistIncendio(inc) == false) { return false; throw new Exception("Nao ha incendio"); }
            else
            {
                try
                {
                    incList.Remove(inc);
                }
                catch (Exception problem) { throw problem; }

                return true;
            }
        }
        public bool RemoveIncendiobyID(int id)
        {
            Incendio aux = incList.Find(item => item.Id == id); //1st lambda expression 
            //Console.WriteLine("{0},{1},{2}", aux.Id, aux.Name, aux.Tipo);
            if (aux.Id == null) { return false; throw new Exception("Nao ha incendio!"); }
            else
            {
                try
                {
                  
                    incList.Remove(aux);
                }
                catch (Exception problem) { throw problem; }

                return true;
            }
        }
        public int Count()
        {
            return incList.Count();

        }
        /// <summary>
        /// metodo para guardar os dados da lista de incendios em bin
        /// </summary>
        /// <param name="fileName">nome do ficheiro</param>
        /// <returns>true or false</returns>
        public bool Save(string fileName)
        {
            // write the data to a file
            var binformatter = new BinaryFormatter();
            try
            {
                Stream s = File.Open(fileName, FileMode.Create, FileAccess.ReadWrite);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, incList);
                s.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }

        public bool Load(string fileName)
        {
            //Hashtable aux = null;
            Stream s = File.Open(fileName, FileMode.Open, FileAccess.Read);
            BinaryFormatter b = new BinaryFormatter();
            incList = (List<Incendio>)b.Deserialize(s);
            s.Close();
            return true;
        }

        #endregion
    }
}
