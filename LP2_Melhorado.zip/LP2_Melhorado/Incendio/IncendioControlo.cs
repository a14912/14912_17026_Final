﻿/*
 Linguagens Programacao II
 Docente- Luis Ferreira
 2019-2020
 Gabriel Vieira - a14912
 Jorge Rocha - a17026
 */


using System;
using System.Collections.Generic;
using System.Text;

namespace Incendio
{
    [Serializable]
    class IncendioControlo
    {
        #region inicia Incendios
        DadosIncendio IncendioControl = new DadosIncendio();

        #endregion

        #region Methods
        public bool CreateIncendio(Incendio i)
        {
            bool res = false;
            try
            {
                res = IncendioControl.CreateIncendio(i); ;
            }
            catch (Exception e) { throw e; }
            return false;
        }
        public List<Incendio> ListAllIncendios()
        {
            return IncendioControl.IncendioList();
        }
        public string NameById(int pp)
        {
            List<Incendio> aux = IncendioControl.IncendioList();

            foreach (Incendio item in aux)
                if (item.Area == pp) return item.Name;
            return ("Not found");
        }
        bool ExistIncendio(Incendio i)
        {
            if (IncendioControl.IncendioList().Contains(i) == false) { return false; }
            else { return true; }
        }
        public bool DeleteIncendio(Incendio i)
        {
            if (ExistIncendio(i) == false) { throw new Exception("No incendio"); }
            else
            {
                try { DeleteIncendio(i); } catch (Exception problem) { throw problem; }
                return true;
            }
        }
        public bool DeleteIncendioById(int id)
        {

            try
            {
                IncendioControl.RemoveIncendiobyID(id);
            }
            catch (Exception e) { Console.WriteLine("Removido:" + e.Message); }
            return true;
        }
        /// <summary>
        /// numero de incendios existentes
        /// </summary>
        /// <returns></returns>
        public int NumberOfIncendios()
        {
            return IncendioControl.Count();
        }

        

        public bool Save(string fileName)
        {
            // write the data to a file
            try
            {
                IncendioControl.Save(fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }
        public bool Load(string fileName)
        {
            try
            {
                IncendioControl.Load(fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }
        #endregion

    }
}
